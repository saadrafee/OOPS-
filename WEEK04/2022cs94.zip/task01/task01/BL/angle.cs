﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace task01.BL
{
    public class Angle
    {
        public int degree;
        public float minutes;
        public char diraction;
        public Angle(int degree,
        float minutes,
        char diraction)
        {
            this.degree = degree;
            this.minutes = minutes;
            this.diraction = diraction;
        }
       

    }
}
