﻿using System;
using EZInput;
using System.IO;
using System.Threading;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace game
{
    class Program
    {
        static void Main(string[] args)
        {
            char[,] Maze = new char[30, 75];
            char[,] player = new char[3, 3];
            char[,] erase = {
                    { ' ', ' ', ' '},
                    { ' ', ' ', ' '},
                    { ' ', ' ', ' '}
                    };
            // axsis
            int playerX = 22;
            int playerY = 19;
            load(Maze, player);

            printmaze(Maze);
            int[] bulletplayerx=new int[200];
            int[] bulletplayery=new int[200];
            int playerbulletidx = 0;
            int bulletcounter = playerbulletidx;
            bool[] isBulletActive=new bool[200];
            bool runing = true;
            while (runing)
            {
                Thread.Sleep(150);
                movebullet(playerbulletidx, isBulletActive, bulletplayerx, bulletplayery, Maze);


                if (EZInput.Keyboard.IsKeyPressed(Key.LeftArrow))
                {
                    moveplayerleft(erase, Maze, ref playerX, ref playerY, player);
                }
                if (EZInput.Keyboard.IsKeyPressed(Key.RightArrow))
                {
                    moveplayerright(erase, Maze, ref playerX, ref playerY, player);
                }
                if (EZInput.Keyboard.IsKeyPressed(Key.UpArrow))
                {
                    moveplayerUp(erase, Maze, ref playerX, ref playerY, player);
                }
                if (EZInput.Keyboard.IsKeyPressed(Key.DownArrow))
                {
                    moveplayerDown(erase, Maze, ref playerX, ref playerY, player);
                }
                if (EZInput.Keyboard.IsKeyPressed(Key.Escape))
                {
                    runing = false;

                }
                if (EZInput.Keyboard.IsKeyPressed(Key.Space))
                {

                    createbullet(bulletplayerx, bulletplayery, isBulletActive, ref playerbulletidx, Maze, playerX, playerY);
                }

            }
        }
        static void load(char[,] printmaze,char[,] player)
        {
            string line;
            string path = "D:\\CS\\semester 2\\PD\\game\\maze.txt";
            StreamReader file = new StreamReader(path);
            int row = 0;
            while (!(file.EndOfStream))
            {
                line = file.ReadLine();
                string[] word = line.Split(',');

                for (int col = 0; col < 75; col++)
                {
                    printmaze[row, col] = Convert.ToChar(int.Parse(word[col]));

                }

                row++;

            }
            file.Close();
             path = "D:\\CS\\semester 2\\PD\\game\\player.txt";
             file = new StreamReader(path);
             row = 0;
            while (!(file.EndOfStream))
            {
                line = file.ReadLine();
                string[] word = line.Split(',');

                for (int col = 0; col < 3; col++)
                {
                    player[row, col] = Convert.ToChar(int.Parse(word[col]));

                }

                row++;

            }
            file.Close();


        }
        static void printmaze(char[,] Maze)
        {
            
            for (int idx = 0; idx < 28; idx++)
            {
                
                for (int idx2 = 0; idx2 < 75; idx2++)
                {
                    Console.Write( Maze[idx,idx2]);
                }
                Console.WriteLine();
            }
        }
        static void printplayer(char[,] player,int playerX, int playerY)
        {
           
            int y = playerY;
            for (int row = 0; row < 3; row++)
            {
                Console.SetCursorPosition(playerX, y);
                for (int col = 0; col < 3; col++)
                {
                    Console.Write( player[row,col]);
                }
                y++;
            }
        }
        static void eraseThech(char[,] erase, int Xaxis, int Yaxis)
        {

            int y = Yaxis;
            for (int row = 0; row < 3; row++)
            {
                Console.SetCursorPosition(Xaxis, y);
                for (int col = 0; col < 3; col++)
                {
                    Console.Write(erase[row, col]);
                }
                y++;
            }
        }
        static void moveplayerleft(char[,] erase, char[,] maze,ref int playerX ,ref int playerY,char[,] player)
        {
            char next = maze[playerY, playerX-1];
            if (next == ' ')
            {
                eraseThech(erase, playerX, playerY);
                playerX--;
                printplayer(player, playerX, playerY);
            }
            
        }
        static void moveplayerright(char[,] erase, char[,] maze, ref int playerX, ref int playerY, char[,] player)
        {
            char next = maze[playerY, playerX+3];
            if (next == ' ')
            {
                eraseThech(erase, playerX, playerY);
                playerX++;
                printplayer(player, playerX, playerY);
            }

        }
        static void moveplayerUp(char[,] erase, char[,] maze, ref int playerX, ref int playerY, char[,] player)
        {
            char next = maze[playerY-1, playerX];
            if (next == ' ')
            {
                eraseThech(erase, playerX, playerY);
                playerY--;
                printplayer(player, playerX, playerY);
            }

        }
        static void moveplayerDown(char[,] erase, char[,] maze, ref int playerX, ref int playerY, char[,] player)
        {
            char next = maze[playerY +3, playerX];
            if (next == ' ')
            {
                eraseThech(erase, playerX, playerY);
                playerY++;
                printplayer(player, playerX, playerY);
            }

        }
        static void printbullet(int x, int y)
        {
            Console.SetCursorPosition(x, y);
            Console.Write( ".");
        }
        static void makeBulletInactive(int x, bool[] isBulletActive)
        {
            isBulletActive[x] = false;
        }
        static void erasebullet(int x, int y)
        {

            Console.SetCursorPosition(x, y);
            Console.Write( " ");
        }
        static void createbullet(int[] bulletplayerx , int[] bulletplayery,bool[] isBulletActive,ref int playerbulletidx,char[,] maze,int playerX,int playerY)
        {
            
            char next;
            char sample = '#';
            next = maze[ playerY - 1,playerX];
            if (next != sample)
            {
                bulletplayerx[playerbulletidx] = playerX + 1;
                bulletplayery[playerbulletidx] = playerY - 1;
                isBulletActive[playerbulletidx] = true;
                Console.SetCursorPosition(bulletplayerx[playerbulletidx],
                       bulletplayery[playerbulletidx]);
                Console.Write( ".");
                playerbulletidx++;
            }
        }
        static void movebullet(int playerbulletidx,bool[] isBulletActive,int[] bulletplayerx,int[] bulletplayery,char[,] maze)
        {

            for (int idx = 0; idx < playerbulletidx; idx++)
            {
                if (isBulletActive[idx] == true)
                {
                    char next = maze[ bulletplayery[idx] - 1,bulletplayerx[idx]];

                    if (next != ' ')
                    {
                        erasebullet(bulletplayerx[idx], bulletplayery[idx]);
                        makeBulletInactive(idx,isBulletActive);
                    }
                    else
                    {
                        erasebullet(bulletplayerx[idx], bulletplayery[idx]);
                        bulletplayery[idx] = bulletplayery[idx] - 1;
                        printbullet(bulletplayerx[idx], bulletplayery[idx]);
                    }
                }
            }
        }
    }
}
